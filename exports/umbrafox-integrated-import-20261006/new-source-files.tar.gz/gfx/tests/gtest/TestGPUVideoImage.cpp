/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#include <thread>
#include <vector>

#include "GPUVideoImage.h"
#include "gtest/gtest.h"
#include "mozilla/Atomics.h"
#include "mozilla/gfx/2D.h"

namespace mozilla::layers {
namespace {

using namespace gfx;

class ReadbackTestManager final : public IGPUVideoSurfaceManager {
 public:
  NS_INLINE_DECL_THREADSAFE_REFCOUNTING(ReadbackTestManager, override)

  already_AddRefed<SourceSurface> Readback(
      const SurfaceDescriptorGPUVideo& aSD) override {
    ++mFullReads;
    return MakeSurface(IntSize(32, 32), aSD);
  }

  already_AddRefed<SourceSurface> Readback(const SurfaceDescriptorGPUVideo& aSD,
                                           const IntSize& aSize) override {
    ++mSizedReads;
    if (mFailNext.exchange(false)) {
      return nullptr;
    }
    if (mReenter) {
      GPUVideoImage* image = mReenter;
      mReenter = nullptr;
      RefPtr<SourceSurface> nested = image->GetAsSourceSurface(aSize);
      EXPECT_TRUE(nested);
    }
    return MakeSurface(mWrongSize || aSize.IsEmpty() ? IntSize(1, 1) : aSize,
                       aSD);
  }

  already_AddRefed<Image> TransferToImage(const SurfaceDescriptorGPUVideo&,
                                          const IntSize&, const ColorDepth&,
                                          YUVColorSpace, ColorSpace2,
                                          TransferFunction,
                                          ColorRange) override {
    return nullptr;
  }

  void DeallocateSurfaceDescriptor(const SurfaceDescriptorGPUVideo&) override {
    ++mDeallocations;
  }

  void OnSetCurrent(const SurfaceDescriptorGPUVideo&) override {}

  Atomic<uint32_t> mSizedReads{0};
  Atomic<uint32_t> mFullReads{0};
  Atomic<uint32_t> mDestroyedSurfaces{0};
  Atomic<uint32_t> mDeallocations{0};
  Atomic<bool> mFailNext{false};
  bool mWrongSize = false;
  int32_t mStride = 0;
  GPUVideoImage* mReenter = nullptr;  // Borrowed only during the reentry test.

 private:
  ~ReadbackTestManager() = default;

  struct Storage {
    RefPtr<ReadbackTestManager> mManager;
    std::vector<uint8_t> mBytes;
    ~Storage() { ++mManager->mDestroyedSurfaces; }
  };

  already_AddRefed<SourceSurface> MakeSurface(
      const IntSize& aSize, const SurfaceDescriptorGPUVideo& aSD) {
    const int32_t stride = mStride ? mStride : aSize.width * 4;
    auto storage = MakeUnique<Storage>();
    storage->mManager = this;
    storage->mBytes.assign(
        size_t(stride) * aSize.height,
        uint8_t(aSD.get_SurfaceDescriptorRemoteDecoder().handle()));
    RefPtr<DataSourceSurface> surface =
        Factory::CreateWrappingDataSourceSurface(
            storage->mBytes.data(), stride, aSize, SurfaceFormat::B8G8R8A8);
    if (!surface) {
      return nullptr;
    }
    static UserDataKey key;
    surface->AddUserData(&key, storage.release(), [](void* aData) {
      delete static_cast<Storage*>(aData);
    });
    return surface.forget();
  }
};

RefPtr<GPUVideoImage> MakeReadbackImage(ReadbackTestManager* aManager,
                                        uint64_t aHandle = 0x5a) {
  SurfaceDescriptorGPUVideo descriptor(SurfaceDescriptorRemoteDecoder(
      aHandle, RemoteDecoderVideoType::DMABuf, Nothing(),
      SurfaceDescriptorRemoteDecoderId{aHandle}));
  return MakeRefPtr<GPUVideoImage>(aManager, descriptor, IntSize(1920, 1080),
                                   ColorDepth::COLOR_8, YUVColorSpace::BT709,
                                   ColorSpace2::BT709, TransferFunction::BT709,
                                   ColorRange::LIMITED);
}

TEST(GPUVideoReadback, SameFrameAndSizeUsesOneReadback)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  RefPtr<SourceSurface> first = image->GetAsSourceSurface(IntSize(110, 75));
  ASSERT_TRUE(first);
  for (int i = 0; i < 8; ++i) {
    RefPtr<SourceSurface> next = image->GetAsSourceSurface(IntSize(110, 75));
    EXPECT_EQ(first, next);
  }
  EXPECT_EQ(uint32_t(manager->mSizedReads), 1u);
  RefPtr<DataSourceSurface> data = first->GetDataSurface();
  DataSourceSurface::ScopedMap map(data, DataSourceSurface::READ);
  ASSERT_TRUE(map.IsMapped());
  for (int y = 0; y < 75; ++y) {
    for (int x = 0; x < 110 * 4; ++x) {
      ASSERT_EQ(map.GetData()[y * map.GetStride() + x], 0x5a);
    }
  }
}

TEST(GPUVideoReadback, DifferentSizesAndImagesCannotReuseTheSurface)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  RefPtr<SourceSurface> small = image->GetAsSourceSurface(IntSize(110, 75));
  RefPtr<SourceSurface> other = image->GetAsSourceSurface(IntSize(120, 80));
  RefPtr<SourceSurface> again = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_NE(small, other);
  EXPECT_EQ(other->GetSize(), IntSize(120, 80));
  EXPECT_EQ(small, again);
  auto secondImage = MakeReadbackImage(manager, 0x6b);
  RefPtr<SourceSurface> second =
      secondImage->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_NE(small, second);
  RefPtr<DataSourceSurface> data = second->GetDataSurface();
  DataSourceSurface::ScopedMap map(data, DataSourceSurface::READ);
  ASSERT_TRUE(map.IsMapped());
  EXPECT_EQ(map.GetData()[0], 0x6b);
  EXPECT_EQ(uint32_t(manager->mSizedReads), 3u);
}

TEST(GPUVideoReadback, FailureAndWrongSizeDoNotPoisonTheCache)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  manager->mFailNext = true;
  RefPtr<SourceSurface> failed = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_FALSE(failed);
  manager->mWrongSize = true;
  RefPtr<SourceSurface> wrong = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_EQ(wrong->GetSize(), IntSize(1, 1));
  manager->mWrongSize = false;
  RefPtr<SourceSurface> good = image->GetAsSourceSurface(IntSize(110, 75));
  RefPtr<SourceSurface> again = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_EQ(good, again);
  EXPECT_EQ(good->GetSize(), IntSize(110, 75));
  EXPECT_EQ(uint32_t(manager->mSizedReads), 3u);
}

TEST(GPUVideoReadback, FullReadbackDoesNotUseSizedCache)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  RefPtr<SourceSurface> sized = image->GetAsSourceSurface(IntSize(32, 32));
  RefPtr<SourceSurface> first = image->GetAsSourceSurface();
  RefPtr<SourceSurface> second = image->GetAsSourceSurface();
  EXPECT_NE(sized, first);
  EXPECT_NE(first, second);
  EXPECT_EQ(uint32_t(manager->mFullReads), 2u);
  EXPECT_EQ(uint32_t(manager->mSizedReads), 1u);
}

TEST(GPUVideoReadback, EmptySizedRequestsKeepExistingReadbackBehavior)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  RefPtr<SourceSurface> first = image->GetAsSourceSurface(IntSize());
  RefPtr<SourceSurface> second = image->GetAsSourceSurface(IntSize());
  EXPECT_NE(first, second);
  EXPECT_EQ(uint32_t(manager->mSizedReads), 2u);
}

TEST(GPUVideoReadback, CacheIsBoundedByActualStrideTimesHeight)
{
  for (const auto size : {IntSize(512, 512), IntSize(513, 512)}) {
    RefPtr manager = new ReadbackTestManager();
    auto image = MakeReadbackImage(manager);
    RefPtr<SourceSurface> first = image->GetAsSourceSurface(size);
    RefPtr<SourceSurface> second = image->GetAsSourceSurface(size);
    EXPECT_EQ(uint32_t(manager->mSizedReads), size.width == 512 ? 1u : 2u);
  }
  RefPtr manager = new ReadbackTestManager();
  manager->mStride = 16384;
  auto image = MakeReadbackImage(manager);
  RefPtr<SourceSurface> first = image->GetAsSourceSurface(IntSize(110, 75));
  RefPtr<SourceSurface> second = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_NE(first, second);
  EXPECT_EQ(uint32_t(manager->mSizedReads), 2u);
}

TEST(GPUVideoReadback, ReadbackDoesNotHoldCacheLock)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  manager->mReenter = image;
  RefPtr<SourceSurface> first = image->GetAsSourceSurface(IntSize(110, 75));
  RefPtr<SourceSurface> next = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_TRUE(first);
  EXPECT_TRUE(next);
  EXPECT_EQ(uint32_t(manager->mSizedReads), 2u);
}

TEST(GPUVideoReadback, ConcurrentReadsConvergeWithoutReplacingTheWinner)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  std::vector<std::thread> threads;
  for (int i = 0; i < 4; ++i) {
    threads.emplace_back([image] {
      for (int j = 0; j < 20; ++j) {
        RefPtr<SourceSurface> surface =
            image->GetAsSourceSurface(IntSize(110, 75));
        EXPECT_TRUE(surface);
        EXPECT_EQ(surface->GetSize(), IntSize(110, 75));
      }
    });
  }
  for (auto& thread : threads) {
    thread.join();
  }
  const uint32_t reads = manager->mSizedReads;
  EXPECT_GE(reads, 1u);
  EXPECT_LE(reads, 4u);
  RefPtr<SourceSurface> first = image->GetAsSourceSurface(IntSize(110, 75));
  RefPtr<SourceSurface> second = image->GetAsSourceSurface(IntSize(110, 75));
  EXPECT_EQ(first, second);
  EXPECT_EQ(uint32_t(manager->mSizedReads), reads);
}

TEST(GPUVideoReadback, ImageDestructionReleasesItsCachedSurface)
{
  RefPtr manager = new ReadbackTestManager();
  auto image = MakeReadbackImage(manager);
  RefPtr<SourceSurface> first = image->GetAsSourceSurface(IntSize(110, 75));
  first = nullptr;
  EXPECT_EQ(uint32_t(manager->mDestroyedSurfaces), 0u);
  image = nullptr;
  EXPECT_EQ(uint32_t(manager->mDestroyedSurfaces), 1u);
  EXPECT_EQ(uint32_t(manager->mDeallocations), 1u);
}

}  // namespace
}  // namespace mozilla::layers
