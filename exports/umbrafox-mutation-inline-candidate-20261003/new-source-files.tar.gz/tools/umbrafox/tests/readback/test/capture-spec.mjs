/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import process from "node:process";
import { setTimeout as delay } from "node:timers/promises";
import { test } from "node:test";
import * as captureModule from "../capture.mjs";
import {
  admitOwned,
  boundedOperation,
  validateLocalWorkload,
  launchRetained,
} from "../capture.mjs";

function fakeLaunch() {
  const child = new EventEmitter();
  child.pid = 98765;
  child.signals = [];
  child.kill = signal => child.signals.push(signal);
  const owned = launchRetained("test", [], {}, () => child);
  return owned;
}

test("local workload rejects malformed definitions without starting operations", () => {
  const valid = {
    mode: "valid",
    limitations: [],
    createServer() {
      throw new Error("Must not execute");
    },
    capture() {
      throw new Error("Must not execute");
    },
  };
  assert.equal(validateLocalWorkload(valid), valid);
  for (const display of ["headless", "headed"]) {
    const definition = { ...valid, display };
    assert.equal(validateLocalWorkload(definition), definition);
  }
  for (const definition of [
    null,
    {},
    { mode: "bad name" },
    { mode: "valid", limitations: [], createServer() {} },
    ...[undefined, true, null, 42, "", "X", "x".repeat(65)].map(mode => ({
      ...valid,
      mode,
    })),
    ...[Array(1), [null], ["x".repeat(301)], Array(5).fill("x")].map(
      limitations => ({ ...valid, limitations })
    ),
    ...[null, false, 1, "", "desktop", {}, ["headed"]].map(display => ({
      ...valid,
      display,
    })),
  ]) {
    assert.throws(() => validateLocalWorkload(definition), /Invalid workload/);
  }
});

test("headless remains the default despite ambient desktop and GPU overrides", () => {
  const environment = Object.freeze({
    MOZ_HEADLESS: "1",
    MOZ_HEADLESS_WIDTH: "1024",
    MOZ_HEADLESS_HEIGHT: "768",
    MOZ_APP_DATA: "/owned/app-data",
    MOZ_LOCAL_APP_DATA: "/owned/local-app-data",
    HOME: "/home/test",
  });
  const input = Object.freeze({
    DISPLAY: ":0",
    XAUTHORITY: "/owned/xauthority",
    MOZ_APP_DATA: "/unowned",
    MOZ_PROFILER_STARTUP: "1",
    LIBGL_ALWAYS_SOFTWARE: "1",
    WAYLAND_DISPLAY: "wayland-0",
  });
  for (const display of [undefined, "headless"]) {
    assert.deepEqual(
      captureModule.localDisplayEnvironment(environment, display, input),
      environment
    );
  }
  const headed = captureModule.localDisplayEnvironment(
    environment,
    "headed",
    input
  );
  assert.deepEqual(headed, {
    MOZ_APP_DATA: "/owned/app-data",
    MOZ_LOCAL_APP_DATA: "/owned/local-app-data",
    HOME: "/home/test",
    DISPLAY: ":0",
    XAUTHORITY: "/owned/xauthority",
  });
  assert.equal(environment.MOZ_HEADLESS, "1");
  assert.equal(input.MOZ_APP_DATA, "/unowned");
});

test("larger artifact allowance is exclusive to explicit headless profiling", () => {
  const definition = {
    mode: "headless-dom-profile-attribution",
    limitations: [],
    createServer() {},
    capture() {},
    artifactPolicy: "profile",
  };
  assert.equal(validateLocalWorkload(definition), definition);
  for (const invalid of [
    { ...definition, mode: "readback" },
    { ...definition, display: "headed" },
    ...[null, false, 0, "", "unlimited", 512, {}].map(artifactPolicy => ({
      ...definition,
      artifactPolicy,
    })),
  ]) {
    assert.throws(() => validateLocalWorkload(invalid), /Invalid workload/);
  }
});

test("headed mode rejects missing, remote or malformed displays and authority paths", () => {
  for (const DISPLAY of [
    undefined,
    null,
    0,
    "",
    "remote:0",
    "localhost:0",
    ":0\0",
    ":-1",
  ]) {
    assert.throws(() =>
      captureModule.localDisplayEnvironment({}, "headed", { DISPLAY })
    );
  }
  for (const XAUTHORITY of [null, 0, "", "relative", "/a\0b"]) {
    assert.throws(() =>
      captureModule.localDisplayEnvironment({}, "headed", {
        DISPLAY: ":0",
        XAUTHORITY,
      })
    );
  }
  assert.deepEqual(
    captureModule.localDisplayEnvironment({}, "headed", { DISPLAY: ":0.1" }),
    { DISPLAY: ":0.1" }
  );
  assert.throws(() =>
    captureModule.localDisplayEnvironment({}, "invalid", { DISPLAY: ":0" })
  );
});

test("expired or aborted budget never starts supplied operation", () => {
  let calls = 0;
  const operation = () => {
    calls++;
    throw new Error("Unexpected operation");
  };
  assert.throws(
    () =>
      boundedOperation(
        {
          remaining() {
            throw new Error("expired");
          },
        },
        undefined,
        operation,
        "test"
      ),
    /expired/
  );
  const controller = new AbortController();
  controller.abort(new Error("aborted"));
  assert.throws(
    () =>
      boundedOperation(
        { remaining: () => 100 },
        controller.signal,
        operation,
        "test"
      ),
    /aborted/
  );
  assert.equal(calls, 0);
});

test(
  "timeout observes late rejection, and successful bounded values pass through",
  { timeout: 1000 },
  async () => {
    let reject;
    const pending = new Promise((resolve, rejectLater) => {
      reject = rejectLater;
    });
    await assert.rejects(
      boundedOperation(
        { remaining: () => 5 },
        undefined,
        () => pending,
        "held"
      ),
      /timed out/
    );
    reject(new Error("Late IO rejection"));
    await delay(10);
    assert.equal(
      await boundedOperation(
        { remaining: () => 100 },
        undefined,
        () => 42,
        "ok"
      ),
      42
    );
  }
);

test("synchronous launch handle is retained through identity success and child exit", async () => {
  const owned = fakeLaunch();
  assert(owned.child);
  const identity = {
    pid: owned.child.pid,
    parent: process.pid,
    group: owned.child.pid,
    session: owned.child.pid,
    start: 123,
  };
  await admitOwned(
    owned,
    operation => operation(),
    async () => identity
  );
  assert.equal(owned.identity, identity);
  owned.child.emit("exit", 0, null);
  owned.child.emit("close");
  assert.deepEqual(await owned.completion, { code: 0, signal: null });
  await owned.closed;
  assert.deepEqual(owned.child.signals, []);
});

test(
  "failed or late admission stops only retained child and cannot mutate identity later",
  { timeout: 1000 },
  async () => {
    for (const mode of ["reject", "late", "mismatch"]) {
      const owned = fakeLaunch();
      let resolve;
      const read =
        mode === "late"
          ? new Promise(resolveLater => {
              resolve = resolveLater;
            })
          : Promise.resolve({ pid: 1 });
      const reader = () =>
        mode === "reject" ? Promise.reject(new Error("read failed")) : read;
      const bounded = operation =>
        boundedOperation(
          { remaining: () => 5 },
          undefined,
          operation,
          "identity"
        );
      await assert.rejects(admitOwned(owned, bounded, reader));
      assert.equal(owned.identity, null);
      assert.deepEqual(owned.child.signals, ["SIGTERM"]);
      resolve?.({
        pid: owned.child.pid,
        parent: process.pid,
        group: owned.child.pid,
        session: owned.child.pid,
      });
      await delay(10);
      assert.equal(owned.identity, null);
      assert.deepEqual(owned.child.signals, ["SIGTERM"]);
    }
  }
);

test("spawn error is observed without killing an already completed child", async () => {
  const owned = fakeLaunch();
  owned.child.emit("error", { code: "ENOENT" });
  assert.deepEqual(await owned.completion, { error: "ENOENT" });
  await assert.rejects(
    admitOwned(owned, () => Promise.reject(new Error("no identity")))
  );
  assert.deepEqual(owned.child.signals, []);
});

test("abort or deadline between admission and dispatch starts no operation", async () => {
  for (const mode of ["abort", "deadline"]) {
    let calls = 0;
    let expired = false;
    const controller = new AbortController();
    const budget = {
      remaining() {
        if (expired) {
          throw new Error("expired");
        }
        return 100;
      },
    };
    const pending = boundedOperation(
      budget,
      controller.signal,
      () => {
        calls++;
      },
      "queued"
    );
    if (mode === "abort") {
      controller.abort(new Error("aborted"));
    } else {
      expired = true;
    }
    await assert.rejects(pending);
    assert.equal(calls, 0);
  }
});
